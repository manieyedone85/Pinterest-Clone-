-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 30, 2016 at 06:32 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pinterest_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `com_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(200) DEFAULT NULL,
  `pid_fk` int(10) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  PRIMARY KEY (`com_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`com_id`, `comment`, `pid_fk`, `uid`) VALUES
(1, 'dsgdfkjghvsdegv', 1, 1),
(2, 'hi', 2, 1),
(3, 'bsdfgdb', 3, 1),
(4, 'gvjhkghjkyt', 3, 1),
(5, 'jhgmfh', 10, 1),
(6, 'fhnbb', 12, 1),
(7, 'fhasiufva sfjvashfk sjdflsjkhafj jhfhasdjfhsa jjghysajhdfvsjd hsjfvhdsfvj vzchgjdfskv jdshgjkd chfvgjzc hgvjldksfhv', 12, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pins`
--

CREATE TABLE IF NOT EXISTS `pins` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pin` varchar(100) DEFAULT NULL,
  `upload_id` int(10) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `pins`
--

INSERT INTO `pins` (`pid`, `pin`, `upload_id`, `uid`) VALUES
(1, 'hi', 1, 1),
(2, 'jkh,hj,', 2, 1),
(3, 'mani', 3, 1),
(4, 'khjl,jhl', 4, 1),
(5, 'yuiolyuioly', 5, 1),
(6, 'uylily', 6, 1),
(7, 'uylioly', 7, 1),
(8, 'uly', 8, 1),
(9, 'uyliy', 9, 1),
(10, 'uyily', 10, 1),
(11, 'ghjmkghjmg', 11, 1),
(12, 'rathu', 12, 1),
(13, 'fcsfca', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_path` varchar(500) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `uploads`
--

INSERT INTO `uploads` (`id`, `image_path`, `uid`) VALUES
(1, '1459311915.png', 1),
(2, '1459311933rt.jpg', 1),
(3, '1459311945r.jpg', 1),
(4, '1459312070.jpg', 1),
(5, '1459312088en_pizza.jpg', 1),
(6, '1459312095able_pizza.jpg', 1),
(7, '1459312102.jpg', 1),
(8, '1459312115rt1.jpg', 1),
(9, '1459312125r.jpg', 1),
(10, '1459312133rt.jpg', 1),
(11, '1459312166r.jpg', 1),
(12, '1459312176rt1.jpg', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
