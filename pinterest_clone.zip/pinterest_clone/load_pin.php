<?php
if(isset($lastid))
{
$lastid=$lastid;
$loadmore="WHERE pid<'$lastid'";
}
else
{
$lastid=0;
$loadmore='';
}

$pin_total = mysql_query("SELECT * from pins");
$pin_count= mysql_num_rows($pin_total);

?>
<div id="container" class="clearfix">
 
<?php

$sql="select * from pins $loadmore order by pid DESC LIMIT 10";
$result=mysql_query($sql);

while($row=mysql_fetch_row($result))
{
$pid=$row[0];
$message=$row[1];
echo "<div class='box col2' id='box$pid'>";
echo "<div class='pin_holder'>";
echo "<div class='data'>";
$upload_id=$row[2];
if($upload_id!=0)
{
$img_query=mysql_query("Select * from uploads where id=$upload_id");
$img_result=mysql_fetch_row($img_query);
$img_path=$img_result[1];
echo "<div style='margin-bottom:5px;'><img src='upload/$img_path' class='pin_image' /></div>";
echo "<div>$message</div></div>";
}
else
{
echo "<div><b>$message</b></div></div>";
}
echo "</div>";
echo "<div style='margin-left:10px;'><a href='#' class='commentopen' id='$pid'><small>Comment</small></a></div>";

?>

<div id="commentload<?php echo $pid;?>">

<?php include("show_comments.php"); ?>

</div>

<div class='commentpost' style='display:none;' id='commentbox<?php echo $pid;?>'>
<div class='commentbox_area'>
<form method="post" action="">
<textarea name="comment" class="comment" maxlength="200"  id="ctextarea<?php echo $pid;?>" placeholder="Add a comment..." maxlength='200'></textarea>
<br/>
<input type="submit"  value=" Comment "  id="<?php echo $pid;?>" class="comment_button"/>
</form>
</div>
</div>

<?php
echo "</div>";
}

?>

</div> <!-- #container -->

<?php
if($pin_count>10)
{
echo "<div id='more$pid' class='morebox'>";
echo "<a href='#' class='more' id='$pid'>Load More Pins</a>";
echo "</div>";
}
 
?>